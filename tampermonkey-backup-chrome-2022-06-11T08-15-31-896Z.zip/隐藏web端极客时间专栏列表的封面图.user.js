// ==UserScript==
// @name         隐藏web端极客时间专栏列表的封面图
// @namespace    http://tampermonkey.net/
// @version      0.1.3
// @description  try to take over the world!
// @require         http://cdn.bootcss.com/jquery/1.8.3/jquery.min.js
// @author       techqu
// @match        https://time.geekbang.org/column/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    $(function () {

     var timer = setInterval(function(){hide_cover(timer)},2000);

     function hide_cover(timer) {
     
             $('img.article-item-cover').css({"display":"none"})
             
       }

     });


})();
